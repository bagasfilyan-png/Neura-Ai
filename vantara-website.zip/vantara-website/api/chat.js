// api/chat.js
//
// Contoh serverless function (format Vercel) yang menjadi perantara aman
// antara frontend dan Anthropic API. API key TIDAK PERNAH dikirim ke
// browser — hanya hidup di environment variable server.
//
// Deploy ke Vercel:
//   1. Push proyek ini ke GitHub, import ke vercel.com.
//   2. Di Vercel dashboard → Settings → Environment Variables, tambahkan:
//        ANTHROPIC_API_KEY = <API key Anda dari console.anthropic.com>
//   3. Redeploy. Endpoint otomatis aktif di /api/chat.
//
// Deploy ke Netlify: pindahkan file ini ke netlify/functions/chat.js dan
// sesuaikan signature handler sesuai dokumentasi Netlify Functions.
//
// GitHub Pages TIDAK mendukung serverless function (hosting statis murni),
// jadi endpoint ini tidak akan berjalan di sana — chatbot akan otomatis
// memakai balasan cadangan (lihat src/lib/api.js).

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { prompt, system } = req.body || {};
  if (!prompt || typeof prompt !== "string") {
    return res.status(400).json({ error: "Field 'prompt' wajib diisi." });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "ANTHROPIC_API_KEY belum diatur di environment server." });
  }

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 700,
        system: system || "Kamu adalah asisten yang membantu dalam Bahasa Indonesia.",
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!r.ok) {
      const errText = await r.text();
      return res.status(r.status).json({ error: "Anthropic API error", detail: errText });
    }

    const data = await r.json();
    const reply = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    return res.status(200).json({ reply });
  } catch (e) {
    return res.status(500).json({ error: "Gagal menghubungi layanan AI." });
  }
}
