import React, { useState, useEffect, useRef, useCallback, useContext, createContext, useMemo } from "react";
import {
  ShoppingCart, Heart, Search, Menu, X, ChevronDown, ChevronRight, ArrowUp, Send, Star,
  Share2, User, LogOut, Mail, Phone, MapPin, CheckCircle, AlertCircle, Sparkles, Clock,
  TrendingUp, Users, Activity, Loader2, ArrowRight, Sun, Moon, Globe, Bot, MessageCircle,
  Facebook, Instagram, Linkedin, Youtube, ZoomIn, Package, Wrench, Briefcase, Award,
  ShieldCheck, Truck, Headphones, LayoutDashboard, Trash2, Plus, Eye, EyeOff, Filter,
} from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { storage } from "./lib/storage";
import { callClaude } from "./lib/api";

/* =========================================================
   CATATAN IMPLEMENTASI — baca README.md untuk detail lengkap
   - Data (produk, artikel, testimoni, pesan, akun, keranjang)
     disimpan via src/lib/storage.js (localStorage browser) —
     persisten per-browser, TAPI bukan database multi-user
     sungguhan. Untuk data bersama antar pengunjung (mis. daftar
     testimoni publik), perlu backend + database (lihat README).
   - Login/Registrasi & Login Admin adalah simulasi — BUKAN sistem
     autentikasi aman (tanpa hashing/server). Ganti dengan auth
     sungguhan (Supabase Auth/Auth0/NextAuth) sebelum produksi.
   - Chatbot memanggil endpoint /api/chat (lihat api/chat.js) yang
     memerlukan ANTHROPIC_API_KEY di environment server saat deploy
     ke Vercel/Netlify. Di GitHub Pages (hosting statis tanpa
     server), endpoint ini tidak tersedia sehingga chatbot otomatis
     memakai balasan cadangan (fallback) — lihat src/lib/api.js.
   - Checkout/pembayaran belum terhubung payment gateway nyata
     (mis. Midtrans/Xendit) — perlu integrasi backend terpisah.
========================================================= */


/* ---------- i18n kamus ringkas ---------- */
const DICT = {
  id: {
    home: "Beranda", products: "Produk", services: "Layanan", testimonials: "Testimoni", about: "Tentang Kami",
    blog: "Blog", faq: "FAQ", contact: "Kontak", dashboard: "Dashboard Admin",
    heroTitle: "Solusi Premium Untuk Hidup & Bisnis Anda", heroDesc: "Vantara menghadirkan produk pilihan dan layanan konsultasi profesional dengan standar kualitas tertinggi.",
    contactUs: "Hubungi Kami", viewProducts: "Lihat Produk", orderNow: "Pesan Sekarang",
    addToCart: "Tambah ke Keranjang", buyNow: "Beli Sekarang", requestQuote: "Minta Penawaran",
    consultNow: "Konsultasi Sekarang", learnMore: "Pelajari Selengkapnya",
  },
  en: {
    home: "Home", products: "Products", services: "Services", testimonials: "Testimonials", about: "About Us",
    blog: "Blog", faq: "FAQ", contact: "Contact", dashboard: "Admin Dashboard",
    heroTitle: "Premium Solutions For Your Life & Business", heroDesc: "Vantara delivers curated products and professional consulting services with the highest quality standards.",
    contactUs: "Contact Us", viewProducts: "View Products", orderNow: "Order Now",
    addToCart: "Add to Cart", buyNow: "Buy Now", requestQuote: "Request a Quote",
    consultNow: "Consult Now", learnMore: "Learn More",
  },
};
const LangCtx = createContext({ lang: "id", t: (k) => k });
const useT = () => useContext(LangCtx);

/* ---------- Toast ---------- */
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg, type = "success") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div style={{ position: "fixed", bottom: 24, left: 24, zIndex: 300, display: "flex", flexDirection: "column", gap: 10 }}>
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.type}`}>{t.type === "success" ? <CheckCircle size={18} /> : <AlertCircle size={18} />}<span>{t.msg}</span></div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = () => useContext(ToastCtx);

/* ---------- Global styles (dark/light via [data-theme]) ---------- */
function GlobalStyles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600;700&display=swap');
      :root{ --gold:#C6A567; --steel:#4A7A96; --radius:16px; }
      [data-theme="dark"]{ --bg:#0F1115; --surface:#171A1F; --surface2:#1D2127; --border:rgba(255,255,255,0.09); --text:#F5F3EE; --text-dim:#A2A6AD; --glass:rgba(255,255,255,0.04); }
      [data-theme="light"]{ --bg:#FAF9F6; --surface:#FFFFFF; --surface2:#F2F0EA; --border:rgba(15,17,21,0.1); --text:#181A1D; --text-dim:#6B6D66; --glass:rgba(15,17,21,0.03); }
      *{box-sizing:border-box;}
      html{scroll-behavior:smooth;}
      .app{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;transition:background .3s,color .3s;overflow-x:hidden;}
      h1,h2,h3,.font-display{font-family:'Playfair Display',serif;}
      .mono{font-family:'Inter',monospace; letter-spacing:0.08em;}
      a{color:inherit;text-decoration:none;}
      ::selection{background:var(--gold);color:#0F1115;}
      *:focus-visible{outline:2px solid var(--gold); outline-offset:2px;}
      @media (prefers-reduced-motion: reduce){*{animation-duration:.01ms !important; transition-duration:.01ms !important;}}

      .glass{background:var(--glass); backdrop-filter:blur(14px); border:1px solid var(--border); border-radius:var(--radius);}
      .card-hover{transition:transform .25s, border-color .25s, box-shadow .25s;}
      .card-hover:hover{transform:translateY(-5px); border-color:var(--gold); box-shadow:0 14px 34px rgba(0,0,0,0.18);}
      .grad-text{background:linear-gradient(90deg,var(--gold),var(--steel));-webkit-background-clip:text;background-clip:text;color:transparent;}
      .btn{padding:12px 24px;border-radius:9px;font-size:0.9rem;display:inline-flex;align-items:center;gap:8px;cursor:pointer;font-weight:600;border:none;}
      .btn-primary{background:var(--gold); color:#181205; transition:transform .2s, box-shadow .2s;}
      .btn-primary:hover{transform:translateY(-2px); box-shadow:0 10px 26px rgba(198,165,103,0.35);}
      .btn-outline{border:1px solid var(--border); background:transparent; color:var(--text); transition:all .2s;}
      .btn-outline:hover{border-color:var(--gold); color:var(--gold);}
      .icon-wrap{width:50px;height:50px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg, rgba(198,165,103,0.16), rgba(74,122,150,0.16)); color:var(--gold);}

      @keyframes fadeUp{from{opacity:0; transform:translateY(26px);} to{opacity:1; transform:translateY(0);}}
      .reveal{opacity:0;} .reveal.in{animation:fadeUp .7s ease forwards;}
      @keyframes spin{to{transform:rotate(360deg);}} .spin{animation:spin 1s linear infinite;}
      @keyframes marquee{from{transform:translateX(0);} to{transform:translateX(-50%);}}
      .marquee-track{display:flex; gap:60px; animation:marquee 24s linear infinite; width:max-content;}
      @keyframes pulse-ring{0%{box-shadow:0 0 0 0 rgba(198,165,103,0.4);}70%{box-shadow:0 0 0 14px rgba(198,165,103,0);}100%{box-shadow:0 0 0 0 rgba(198,165,103,0);}}
      .pulse{animation:pulse-ring 2.4s infinite;}

      input,textarea,select{width:100%; padding:12px 15px; border-radius:9px; border:1px solid var(--border); background:var(--surface2); color:var(--text); font-family:'Inter'; font-size:0.92rem;}
      input:focus,textarea:focus,select:focus{border-color:var(--gold);}
      label{display:block; font-size:0.8rem; color:var(--text-dim); margin-bottom:6px; font-weight:600;}
      textarea{resize:vertical; min-height:100px;}

      .toast{display:flex;align-items:center;gap:10px;padding:14px 18px;border-radius:10px;background:var(--surface);border:1px solid var(--border);font-size:0.86rem;min-width:250px;box-shadow:0 10px 28px rgba(0,0,0,0.3);color:var(--text);}
      .toast.success{border-color:var(--gold);} .toast.error{border-color:#E15C5C; color:#E15C5C;}

      .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.65);backdrop-filter:blur(3px);z-index:400;display:flex;align-items:center;justify-content:center;padding:20px;}
      .modal-box{max-width:640px;width:100%;max-height:86vh;overflow-y:auto;}
      .nav-link{position:relative;font-weight:600;font-size:0.86rem;color:var(--text-dim);cursor:pointer;transition:color .2s;}
      .nav-link::after{content:"";position:absolute;left:0;bottom:-6px;height:2px;width:0;background:var(--gold);transition:width .25s;}
      .nav-link:hover,.nav-link.active{color:var(--text);} .nav-link:hover::after,.nav-link.active::after{width:100%;}
      .chip{padding:7px 15px;border-radius:100px;font-size:0.78rem;font-weight:600;border:1px solid var(--border);cursor:pointer;color:var(--text-dim);transition:all .2s;}
      .chip.active{background:var(--gold);color:#181205;border-color:transparent;}
      .accordion-icon{transition:transform .25s;} .faq-item.open .accordion-icon{transform:rotate(180deg);}
    `}</style>
  );
}

/* ---------- helpers/hooks ---------- */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal:not(.in)");
    const io = new IntersectionObserver((entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in")), { threshold: 0.15 });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  });
}
function Counter({ to, suffix = "" }) {
  const [val, setVal] = useState(0);
  const ref = useRef(null); const started = useRef(false);
  useEffect(() => {
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !started.current) {
        started.current = true;
        const start = performance.now(), dur = 1500;
        function tick(now) { const p = Math.min(1, (now - start) / dur); setVal(Math.floor(p * to)); if (p < 1) requestAnimationFrame(tick); }
        requestAnimationFrame(tick);
      }
    }, { threshold: 0.4 });
    if (ref.current) io.observe(ref.current);
    return () => io.disconnect();
  }, [to]);
  return <span ref={ref}>{val.toLocaleString("id-ID")}{suffix}</span>;
}
function Modal({ onClose, children, wide }) {
  useEffect(() => { const k = (e) => e.key === "Escape" && onClose(); window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); }, [onClose]);
  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-box glass" style={{ padding: 26, position: "relative", maxWidth: wide ? 880 : 640 }} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="btn-outline btn" style={{ position: "absolute", top: 14, right: 14, padding: 8 }} aria-label="Tutup"><X size={16} /></button>
        {children}
      </div>
    </div>
  );
}
function Breadcrumb({ trail, setPage }) {
  return (
    <div className="mono" style={{ fontSize: "0.74rem", color: "var(--text-dim)", marginBottom: 20, display: "flex", gap: 6, alignItems: "center" }}>
      <span onClick={() => setPage("home")} style={{ cursor: "pointer" }}>Beranda</span>
      {trail.map((t) => <React.Fragment key={t}><ChevronRight size={12} /><span>{t}</span></React.Fragment>)}
    </div>
  );
}

/* =========================================================
   DATA
========================================================= */
const CATS = ["Semua", "Elektronik", "Rumah Tangga", "Aksesoris", "Gaya Hidup"];
const PRODUCTS_SEED = [
  { id: "p1", name: "Vantara SmartHub X1", cat: "Elektronik", price: 1290000, emoji: "📡", desc: "Hub pintar untuk mengontrol perangkat rumah dari satu aplikasi.", date: "2026-07-01" },
  { id: "p2", name: "Vantara AeroLamp", cat: "Rumah Tangga", price: 459000, emoji: "💡", desc: "Lampu meja adaptif dengan sensor cahaya otomatis.", date: "2026-06-15" },
  { id: "p3", name: "Vantara LeatherCase Pro", cat: "Aksesoris", price: 329000, emoji: "💼", desc: "Case kulit premium buatan tangan untuk perangkat kerja Anda.", date: "2026-07-10" },
  { id: "p4", name: "Vantara PureAir Diffuser", cat: "Gaya Hidup", price: 599000, emoji: "🌿", desc: "Diffuser aroma dengan desain minimalis untuk ruang kerja tenang.", date: "2026-05-20" },
  { id: "p5", name: "Vantara SoundBar Slim", cat: "Elektronik", price: 1890000, emoji: "🔊", desc: "Soundbar tipis dengan kualitas audio jernih untuk ruang keluarga.", date: "2026-07-18" },
  { id: "p6", name: "Vantara ErgoDesk Mat", cat: "Rumah Tangga", price: 279000, emoji: "🖥️", desc: "Alas meja ergonomis dengan permukaan anti-gores.", date: "2026-04-28" },
];
const SERVICES = [
  { id: "s1", icon: Briefcase, name: "Konsultasi Bisnis", desc: "Pendampingan strategi pertumbuhan usaha oleh konsultan berpengalaman." },
  { id: "s2", icon: Wrench, name: "Instalasi & Setup Produk", desc: "Tim teknisi kami membantu pemasangan produk Vantara di lokasi Anda." },
  { id: "s3", icon: ShieldCheck, name: "Layanan Purna Jual", desc: "Garansi dan dukungan teknis untuk seluruh produk yang Anda beli." },
  { id: "s4", icon: Truck, name: "Pengiriman & Logistik", desc: "Pengiriman terjadwal ke seluruh Indonesia dengan pelacakan real-time." },
];
const TESTIMONIALS_SEED = [
  { id: "t1", name: "Ratna Kusuma", role: "Pemilik Usaha Retail", rating: 5, text: "Layanan konsultasinya benar-benar membantu kami menata ulang strategi penjualan.", avatar: "R" },
  { id: "t2", name: "Fajar Nugroho", role: "Manajer Operasional", rating: 5, text: "Produk SmartHub-nya stabil dan supportnya responsif, sangat direkomendasikan.", avatar: "F" },
  { id: "t3", name: "Meilani Putri", role: "Desainer Interior", rendered: true, rating: 4, text: "Kualitas produk premium, pengiriman juga tepat waktu ke Bandung.", avatar: "M" },
];
const ARTICLES = [
  { id: 1, title: "5 Cara Rumah Pintar Menghemat Energi", category: "Tips", excerpt: "Penerapan otomasi sederhana yang terbukti menekan konsumsi listrik bulanan.", read: 6, date: "10 Jul 2026", emoji: "🏠" },
  { id: 2, title: "Tren Gaya Hidup Minimalis 2026", category: "Gaya Hidup", excerpt: "Bagaimana pendekatan minimalis memengaruhi pilihan produk konsumen masa kini.", read: 5, date: "16 Jul 2026", emoji: "🍃" },
  { id: 3, title: "Panduan Memilih Konsultan Bisnis yang Tepat", category: "Bisnis", excerpt: "Hal-hal yang perlu dipertimbangkan sebelum menunjuk mitra konsultasi.", read: 8, date: "22 Jul 2026", emoji: "📈" },
  { id: 4, title: "Studi Kasus: Efisiensi Operasional Klien Retail", category: "Bisnis", excerpt: "Bagaimana salah satu klien kami memangkas biaya operasional 18% dalam 3 bulan.", read: 7, date: "24 Jul 2026", emoji: "📊" },
];
const ART_CATS = ["Semua", "Tips", "Gaya Hidup", "Bisnis"];
const FAQS = [
  { q: "Berapa lama waktu pengiriman produk?", a: "Estimasi 2–5 hari kerja untuk wilayah Jawa, dan 4–8 hari kerja untuk luar Jawa, tergantung jasa ekspedisi yang dipilih." },
  { q: "Apakah tersedia layanan konsultasi gratis?", a: "Kami menyediakan sesi konsultasi awal gratis selama 30 menit sebelum Anda memutuskan paket layanan." },
  { q: "Bagaimana kebijakan garansi produk?", a: "Seluruh produk Vantara memiliki garansi resmi 12 bulan untuk kerusakan pabrik." },
  { q: "Apakah bisa request custom untuk kebutuhan korporat?", a: "Bisa. Hubungi tim sales kami melalui formulir kontak untuk kebutuhan pemesanan dalam jumlah besar." },
];
const CLIENTS = ["ARTHA GROUP", "SEJAHTERA CORP", "MITRA NUSA", "BINTANG LOGISTIK", "CIPTA DIGITAL", "SENTOSA RETAIL"];
const NAV_KEYS = ["home", "products", "services", "testimonials", "about", "blog", "faq", "contact", "dashboard"];

/* =========================================================
   LOADING + PROGRESS + BACK TO TOP + PROMO POPUP
========================================================= */
function LoadingScreen({ show }) {
  const [pct, setPct] = useState(0);
  useEffect(() => { if (!show) return; const t = setInterval(() => setPct((p) => Math.min(100, p + Math.random() * 20)), 130); return () => clearInterval(t); }, [show]);
  if (!show) return null;
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 999, background: "#0F1115", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 18 }}>
      <div className="pulse" style={{ width: 76, height: 76, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg,var(--gold),var(--steel))" }}>
        <Award size={32} color="#181205" />
      </div>
      <div className="font-display" style={{ fontSize: "1.4rem", color: "#F5F3EE" }}>VANTARA</div>
      <div style={{ width: 200, height: 3, borderRadius: 4, background: "rgba(255,255,255,0.1)", overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: "linear-gradient(90deg,var(--gold),var(--steel))", transition: "width .15s" }} />
      </div>
    </div>
  );
}
function ScrollProgress() {
  const [w, setW] = useState(0);
  useEffect(() => {
    const onScroll = () => { const h = document.documentElement; const pct = h.scrollTop / (h.scrollHeight - h.clientHeight) * 100; setW(isFinite(pct) ? pct : 0); };
    window.addEventListener("scroll", onScroll); return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return <div style={{ position: "fixed", top: 0, left: 0, height: 3, width: `${w}%`, background: "linear-gradient(90deg,var(--gold),var(--steel))", zIndex: 200, transition: "width .1s" }} />;
}
function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => { const f = () => setShow(window.scrollY > 500); window.addEventListener("scroll", f); return () => window.removeEventListener("scroll", f); }, []);
  if (!show) return null;
  return <button className="btn-primary btn" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Kembali ke atas" style={{ position: "fixed", bottom: 24, right: 96, width: 44, height: 44, borderRadius: "50%", padding: 0, justifyContent: "center", zIndex: 190 }}><ArrowUp size={17} /></button>;
}
function PromoPopup() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    (async () => {
      try { const r = await storage.get("promo_seen", false); if (!r?.value) setTimeout(() => setShow(true), 2200); }
      catch (e) { setTimeout(() => setShow(true), 2200); }
    })();
  }, []);
  async function close() { setShow(false); try { await storage.set("promo_seen", "1", false); } catch (e) {} }
  if (!show) return null;
  return (
    <div className="modal-overlay" onClick={close}>
      <div className="glass" style={{ maxWidth: 420, padding: 32, textAlign: "center", position: "relative" }} onClick={(e) => e.stopPropagation()}>
        <button onClick={close} className="btn-outline btn" style={{ position: "absolute", top: 14, right: 14, padding: 7 }}><X size={15} /></button>
        <Sparkles size={30} color="var(--gold)" style={{ margin: "0 auto 12px" }} />
        <h3 style={{ fontSize: "1.3rem", marginBottom: 8 }}>Promo Spesial Minggu Ini</h3>
        <p style={{ color: "var(--text-dim)", fontSize: "0.9rem", marginBottom: 20 }}>Dapatkan diskon 15% untuk konsultasi bisnis pertama Anda. Berlaku terbatas.</p>
        <button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }} onClick={close}>Klaim Sekarang</button>
      </div>
    </div>
  );
}

/* =========================================================
   NAVBAR + FOOTER
========================================================= */
function Navbar({ page, setPage, session, theme, setTheme, lang, setLang, cartCount, setShowCart, setShowChat, setShowSearch }) {
  const t = useT().t;
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => { const f = () => setScrolled(window.scrollY > 20); window.addEventListener("scroll", f); return () => window.removeEventListener("scroll", f); }, []);
  const go = (id) => { setPage(id); setOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 150, background: scrolled ? "var(--bg)" : "transparent", borderBottom: scrolled ? "1px solid var(--border)" : "1px solid transparent", backdropFilter: "blur(12px)", transition: "all .3s" }}>
      <div style={{ maxWidth: 1220, margin: "0 auto", padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14 }}>
        <button onClick={() => go("home")} className="font-display" style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "1.25rem", background: "none", border: "none", color: "var(--text)", cursor: "pointer" }}>
          <Award size={20} color="var(--gold)" /> VANTARA
        </button>
        <nav style={{ display: "flex", gap: 22 }} className="nav-desktop">
          {NAV_KEYS.map((k) => <span key={k} className={`nav-link ${page === k ? "active" : ""}`} onClick={() => go(k)}>{t(k)}</span>)}
        </nav>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button className="btn-outline btn" style={{ padding: 8 }} onClick={() => setShowSearch(true)} aria-label="Cari"><Search size={15} /></button>
          <button className="btn-outline btn" style={{ padding: 8 }} onClick={() => setLang(lang === "id" ? "en" : "id")} aria-label="Ganti bahasa"><Globe size={15} /> <span className="mono" style={{ fontSize: "0.7rem" }}>{lang.toUpperCase()}</span></button>
          <button className="btn-outline btn" style={{ padding: 8 }} onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="Ganti tema">{theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}</button>
          <button className="btn-outline btn" style={{ padding: 8, position: "relative" }} onClick={() => setShowCart(true)} aria-label="Keranjang">
            <ShoppingCart size={15} />
            {cartCount > 0 && <span style={{ position: "absolute", top: -6, right: -6, background: "var(--gold)", color: "#181205", fontSize: "0.62rem", fontWeight: 700, borderRadius: "50%", width: 17, height: 17, display: "flex", alignItems: "center", justifyContent: "center" }}>{cartCount}</span>}
          </button>
          <button className="btn-outline btn" style={{ padding: 8 }} onClick={() => go("auth")} aria-label="Akun">{session ? <span className="mono" style={{ fontSize: "0.72rem" }}>{session.name.split(" ")[0]}</span> : <User size={15} />}</button>
          <button className="btn-outline btn nav-burger" style={{ padding: 8, display: "none" }} onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X size={15} /> : <Menu size={15} />}</button>
        </div>
      </div>
      {open && <div className="glass" style={{ margin: "0 16px 16px", padding: 16, display: "flex", flexDirection: "column", gap: 14 }}>{NAV_KEYS.map((k) => <span key={k} className="nav-link" onClick={() => go(k)}>{t(k)}</span>)}</div>}
      <style>{`@media (max-width: 980px){ .nav-desktop{display:none;} .nav-burger{display:inline-flex !important;} }`}</style>
    </header>
  );
}
function Footer({ setPage }) {
  const t = useT().t;
  const socials = [Facebook, Instagram, Linkedin, Youtube];
  return (
    <footer style={{ borderTop: "1px solid var(--border)", padding: "48px 24px 24px", background: "var(--surface)" }}>
      <div style={{ maxWidth: 1220, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 30, marginBottom: 30 }}>
          <div style={{ maxWidth: 280 }}>
            <div className="font-display" style={{ fontSize: "1.2rem", display: "flex", alignItems: "center", gap: 8 }}><Award size={18} color="var(--gold)" /> VANTARA</div>
            <p style={{ color: "var(--text-dim)", fontSize: "0.85rem", marginTop: 10 }}>Produk pilihan & layanan konsultasi profesional untuk kehidupan dan bisnis Anda.</p>
            <div style={{ display: "flex", gap: 8, marginTop: 14 }}>{socials.map((Icon, i) => <a key={i} href="#" className="btn-outline" style={{ width: 34, height: 34, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon size={14} /></a>)}</div>
          </div>
          <div>
            <div className="mono" style={{ fontSize: "0.7rem", color: "var(--gold)", marginBottom: 12 }}>HALAMAN</div>
            {NAV_KEYS.map((k) => <div key={k} onClick={() => setPage(k)} style={{ fontSize: "0.84rem", color: "var(--text-dim)", marginBottom: 9, cursor: "pointer" }}>{t(k)}</div>)}
          </div>
        </div>
        <div style={{ borderTop: "1px solid var(--border)", paddingTop: 18, fontSize: "0.76rem", color: "var(--text-dim)", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
          <span>© 2026 Vantara. Seluruh hak cipta dilindungi.</span><span>Dibangun dengan presisi & dedikasi.</span>
        </div>
      </div>
    </footer>
  );
}

/* =========================================================
   CHATBOT / LIVE CHAT
========================================================= */
function ChatWidget({ open, setOpen }) {
  const [messages, setMessages] = useState([{ role: "assistant", text: "Halo! Saya asisten Vantara. Ada yang bisa saya bantu seputar produk atau layanan kami?" }]);
  const [input, setInput] = useState(""); const [loading, setLoading] = useState(false);
  const endRef = useRef(null); const toast = useToast();
  useEffect(() => { (async () => { try { const r = await storage.get("chat_history", false); if (r?.value) setMessages(JSON.parse(r.value)); } catch (e) {} })(); }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, open]);
  async function send(text) {
    const q = (text ?? input).trim(); if (!q) return;
    const next = [...messages, { role: "user", text: q }]; setMessages(next); setInput(""); setLoading(true);
    try {
      const reply = await callClaude(q, "Kamu adalah asisten live chat untuk situs bisnis bernama Vantara yang menjual produk lifestyle/elektronik premium (SmartHub, lampu, case, diffuser, soundbar) dan layanan (konsultasi bisnis, instalasi, purna jual, logistik). Jawab singkat, sopan, dan dalam Bahasa Indonesia.");
      const withReply = [...next, { role: "assistant", text: reply }]; setMessages(withReply);
      try { await storage.set("chat_history", JSON.stringify(withReply.slice(-30)), false); } catch (e) {}
    } catch (e) { toast("Gagal menghubungi live chat.", "error"); } finally { setLoading(false); }
  }
  if (!open) return null;
  return (
    <div className="glass" style={{ position: "fixed", bottom: 24, right: 24, width: 350, maxWidth: "90vw", height: 460, zIndex: 250, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <div style={{ padding: 14, borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", gap: 9, alignItems: "center" }}><div className="icon-wrap" style={{ width: 32, height: 32 }}><MessageCircle size={15} /></div><div><div style={{ fontWeight: 700, fontSize: "0.86rem" }}>Live Chat Vantara</div><div className="mono" style={{ fontSize: "0.64rem", color: "var(--gold)" }}>● Online</div></div></div>
        <button onClick={() => setOpen(false)} className="btn-outline btn" style={{ padding: 6 }}><X size={13} /></button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: 14, display: "flex", flexDirection: "column", gap: 10 }}>
        {messages.map((m, i) => <div key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "85%", padding: "9px 13px", borderRadius: 12, fontSize: "0.84rem", background: m.role === "user" ? "var(--gold)" : "var(--surface2)", color: m.role === "user" ? "#181205" : "var(--text)" }}>{m.text}</div>)}
        {loading && <div style={{ color: "var(--text-dim)", fontSize: "0.78rem", display: "flex", gap: 6, alignItems: "center" }}><Loader2 size={13} className="spin" /> mengetik...</div>}
        <div ref={endRef} />
      </div>
      <div style={{ padding: 10, borderTop: "1px solid var(--border)", display: "flex", gap: 8 }}>
        <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Tulis pesan..." />
        <button className="btn-primary btn" style={{ padding: 11 }} onClick={() => send()} aria-label="Kirim"><Send size={14} /></button>
      </div>
    </div>
  );
}

/* =========================================================
   SEARCH OVERLAY
========================================================= */
function SearchOverlay({ show, onClose, setPage }) {
  const [q, setQ] = useState("");
  if (!show) return null;
  const ql = q.toLowerCase();
  const pr = PRODUCTS_SEED.filter((p) => p.name.toLowerCase().includes(ql));
  const ar = ARTICLES.filter((a) => a.title.toLowerCase().includes(ql));
  return (
    <div className="modal-overlay" onClick={onClose} style={{ alignItems: "flex-start", paddingTop: "10vh" }}>
      <div className="glass" style={{ maxWidth: 600, width: "100%", padding: 18 }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <Search size={17} color="var(--gold)" />
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari produk, artikel..." style={{ border: "none", background: "none" }} />
          <button onClick={onClose} className="btn-outline btn" style={{ padding: 7 }}><X size={13} /></button>
        </div>
        {q && (
          <div style={{ marginTop: 14, maxHeight: "50vh", overflowY: "auto" }}>
            {pr.length === 0 && ar.length === 0 && <p style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>Tidak ada hasil untuk "{q}".</p>}
            {pr.map((p) => <div key={p.id} onClick={() => { setPage("products"); onClose(); }} className="search-item" style={{ padding: "9px 6px", cursor: "pointer", borderRadius: 7, fontSize: "0.88rem" }}>{p.emoji} {p.name}</div>)}
            {ar.map((a) => <div key={a.id} onClick={() => { setPage("blog"); onClose(); }} className="search-item" style={{ padding: "9px 6px", cursor: "pointer", borderRadius: 7, fontSize: "0.88rem" }}>{a.emoji} {a.title}</div>)}
          </div>
        )}
      </div>
      <style>{`.search-item:hover{background:var(--surface2);}`}</style>
    </div>
  );
}

/* =========================================================
   CART DRAWER
========================================================= */
function CartDrawer({ show, onClose, cart, setCart, setPage }) {
  const toast = useToast();
  if (!show) return null;
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  async function updateCart(next) { setCart(next); try { await storage.set("cart", JSON.stringify(next), false); } catch (e) {} }
  function removeItem(id) { updateCart(cart.filter((i) => i.id !== id)); }
  function changeQty(id, d) { updateCart(cart.map((i) => i.id === id ? { ...i, qty: Math.max(1, i.qty + d) } : i)); }
  return (
    <div className="modal-overlay" onClick={onClose} style={{ justifyContent: "flex-end", padding: 0 }}>
      <div className="glass" style={{ width: 380, maxWidth: "92vw", height: "100%", borderRadius: 0, padding: 22, display: "flex", flexDirection: "column" }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h3 style={{ fontSize: "1.1rem" }}>Keranjang ({cart.length})</h3>
          <button onClick={onClose} className="btn-outline btn" style={{ padding: 7 }}><X size={14} /></button>
        </div>
        <div style={{ flex: 1, overflowY: "auto" }}>
          {cart.length === 0 && <p style={{ color: "var(--text-dim)", fontSize: "0.88rem" }}>Keranjang Anda masih kosong.</p>}
          {cart.map((i) => (
            <div key={i.id} style={{ display: "flex", gap: 12, padding: "12px 0", borderBottom: "1px solid var(--border)" }}>
              <div style={{ fontSize: "1.8rem" }}>{i.emoji}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: "0.86rem" }}>{i.name}</div>
                <div className="mono" style={{ fontSize: "0.78rem", color: "var(--gold)" }}>Rp {i.price.toLocaleString("id-ID")}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
                  <button onClick={() => changeQty(i.id, -1)} className="btn-outline btn" style={{ padding: "2px 9px" }}>-</button>
                  <span style={{ fontSize: "0.85rem" }}>{i.qty}</span>
                  <button onClick={() => changeQty(i.id, 1)} className="btn-outline btn" style={{ padding: "2px 9px" }}>+</button>
                  <Trash2 size={14} onClick={() => removeItem(i.id)} style={{ cursor: "pointer", marginLeft: "auto", color: "var(--text-dim)" }} />
                </div>
              </div>
            </div>
          ))}
        </div>
        {cart.length > 0 && (
          <div style={{ borderTop: "1px solid var(--border)", paddingTop: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14, fontWeight: 700 }}><span>Total</span><span className="grad-text">Rp {total.toLocaleString("id-ID")}</span></div>
            <button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }} onClick={() => { toast("Checkout memerlukan integrasi payment gateway di backend produksi (mis. Midtrans/Xendit). Untuk demo, hubungi tim sales via halaman Kontak.", "error"); }}>Checkout</button>
            <button className="btn-outline btn" style={{ width: "100%", justifyContent: "center", marginTop: 8 }} onClick={() => { onClose(); setPage("contact"); }}>Minta Penawaran via Kontak</button>
          </div>
        )}
      </div>
    </div>
  );
}

/* =========================================================
   HOME
========================================================= */
function Home({ setPage, setShowChat }) {
  useReveal(); const t = useT().t;
  return (
    <>
      <section style={{ position: "relative", minHeight: "88vh", display: "flex", alignItems: "center", paddingTop: 60, overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse 55% 45% at 75% 25%, rgba(198,165,103,0.16), transparent 70%), radial-gradient(ellipse 45% 40% at 15% 80%, rgba(74,122,150,0.14), transparent 70%)" }} />
        <div style={{ maxWidth: 1220, margin: "0 auto", padding: "0 24px", position: "relative", zIndex: 2, display: "grid", gridTemplateColumns: "1.1fr 0.9fr", gap: 40, alignItems: "center" }} className="grid-responsive-2">
          <div>
            <div className="reveal in glass" style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "7px 16px", marginBottom: 22, fontSize: "0.78rem" }}><Award size={13} color="var(--gold)" /> Trusted by 500+ businesses</div>
            <h1 className="reveal in" style={{ fontSize: "clamp(2.2rem,5vw,3.6rem)", lineHeight: 1.12, marginBottom: 20 }}>{t("heroTitle")}</h1>
            <p className="reveal in" style={{ color: "var(--text-dim)", fontSize: "1.04rem", maxWidth: 480, marginBottom: 30 }}>{t("heroDesc")}</p>
            <div className="reveal in" style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <button className="btn-primary btn" onClick={() => setPage("contact")}>{t("contactUs")} <ArrowRight size={15} /></button>
              <button className="btn-outline btn" onClick={() => setPage("products")}>{t("viewProducts")}</button>
              <button className="btn-outline btn" onClick={() => setPage("contact")}>{t("orderNow")}</button>
            </div>
            <div style={{ display: "flex", gap: 40, marginTop: 50, flexWrap: "wrap" }}>
              {[["Klien Puas", 1280, "+"], ["Produk Terjual", 9600, "+"], ["Tahun Pengalaman", 8, "+"]].map(([lbl, n, s]) => (
                <div key={lbl} className="reveal in"><div className="font-display grad-text" style={{ fontSize: "2rem" }}><Counter to={n} suffix={s} /></div><div style={{ fontSize: "0.78rem", color: "var(--text-dim)" }}>{lbl}</div></div>
              ))}
            </div>
          </div>
          <div className="reveal in glass" style={{ aspectRatio: "4/5", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "6rem", background: "linear-gradient(160deg, var(--surface2), var(--surface))" }}>📡</div>
        </div>
      </section>

      <div style={{ padding: "40px 0", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)", overflow: "hidden" }}>
        <div className="marquee-track">
          {[...CLIENTS, ...CLIENTS].map((c, i) => <span key={i} className="mono" style={{ fontSize: "0.85rem", color: "var(--text-dim)", whiteSpace: "nowrap" }}>{c}</span>)}
        </div>
      </div>

      <section style={{ padding: "90px 24px", maxWidth: 1220, margin: "0 auto" }}>
        <div className="reveal" style={{ textAlign: "center", marginBottom: 46 }}><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>KEUNGGULAN KAMI</span><h2 style={{ fontSize: "clamp(1.7rem,3.4vw,2.4rem)", marginTop: 10 }}>Dipercaya Karena Konsisten</h2></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 18 }} className="grid-responsive-4">
          {[[ShieldCheck, "Garansi Resmi", "Semua produk bergaransi 12 bulan penuh."], [Truck, "Pengiriman Cepat", "Jangkauan seluruh Indonesia dengan tracking."], [Headphones, "Support 24/7", "Tim dukungan siap membantu kapan saja."], [Award, "Kualitas Premium", "Kurasi ketat untuk setiap produk & layanan."]].map(([Icon, ti, d]) => (
            <div key={ti} className="glass card-hover reveal" style={{ padding: 24 }}><div className="icon-wrap"><Icon size={20} /></div><h3 style={{ fontSize: "1rem", textTransform: "none", margin: "14px 0 6px" }}>{ti}</h3><p style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>{d}</p></div>
          ))}
        </div>
      </section>
      <style>{`@media(max-width:900px){.grid-responsive-2{grid-template-columns:1fr !important;} .grid-responsive-4{grid-template-columns:repeat(2,1fr) !important;}}`}</style>
    </>
  );
}

/* =========================================================
   PRODUCTS
========================================================= */
function ProductDetail({ product, onClose, addToCart, wishlist, toggleWish }) {
  const [zoom, setZoom] = useState(false);
  return (
    <Modal onClose={onClose} wide>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }} className="grid-responsive-2">
        <div onClick={() => setZoom(!zoom)} className="glass" style={{ aspectRatio: "1", display: "flex", alignItems: "center", justifyContent: "center", fontSize: zoom ? "9rem" : "6rem", cursor: "zoom-in", transition: "font-size .3s", overflow: "hidden" }}>{product.emoji}</div>
        <div>
          <span className="chip active" style={{ padding: "4px 12px", fontSize: "0.7rem" }}>{product.cat}</span>
          <h2 style={{ margin: "12px 0 8px", textTransform: "none", fontSize: "1.4rem" }}>{product.name}</h2>
          <div className="grad-text font-display" style={{ fontSize: "1.6rem", marginBottom: 12 }}>Rp {product.price.toLocaleString("id-ID")}</div>
          <p style={{ color: "var(--text-dim)", fontSize: "0.9rem", marginBottom: 20 }}>{product.desc}</p>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button className="btn-primary btn" onClick={() => addToCart(product)}><ShoppingCart size={15} /> Tambah ke Keranjang</button>
            <button className="btn-outline btn" onClick={() => addToCart(product, true)}>Beli Sekarang</button>
            <button className="btn-outline btn" onClick={() => toggleWish(product.id)}><Heart size={15} fill={wishlist[product.id] ? "#E15C5C" : "none"} color={wishlist[product.id] ? "#E15C5C" : undefined} /></button>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function Products({ setPage, session }) {
  useReveal(); const toast = useToast();
  const [cat, setCat] = useState("Semua"); const [q, setQ] = useState(""); const [sort, setSort] = useState("newest");
  const [detail, setDetail] = useState(null); const [wishlist, setWishlist] = useState({});
  const [products] = useState(PRODUCTS_SEED);

  useEffect(() => { (async () => { try { const r = await storage.get("wishlist", false); if (r?.value) setWishlist(JSON.parse(r.value)); } catch (e) {} })(); }, []);
  async function toggleWish(id) {
    const next = { ...wishlist, [id]: !wishlist[id] }; setWishlist(next);
    try { await storage.set("wishlist", JSON.stringify(next), false); } catch (e) {}
    toast(next[id] ? "Ditambahkan ke wishlist." : "Dihapus dari wishlist.");
  }
  async function addToCart(p, buyNow = false) {
    try {
      const r = await storage.get("cart", false).catch(() => null);
      const cur = r?.value ? JSON.parse(r.value) : [];
      const exist = cur.find((i) => i.id === p.id);
      const next = exist ? cur.map((i) => i.id === p.id ? { ...i, qty: i.qty + 1 } : i) : [...cur, { ...p, qty: 1 }];
      await storage.set("cart", JSON.stringify(next), false);
      toast(buyNow ? "Produk siap checkout — buka keranjang untuk lanjut." : "Produk ditambahkan ke keranjang.");
      setDetail(null);
    } catch (e) { toast("Gagal menambah ke keranjang.", "error"); }
  }

  let filtered = products.filter((p) => (cat === "Semua" || p.cat === cat) && p.name.toLowerCase().includes(q.toLowerCase()));
  filtered = [...filtered].sort((a, b) => sort === "price-asc" ? a.price - b.price : sort === "price-desc" ? b.price - a.price : sort === "name" ? a.name.localeCompare(b.name) : new Date(b.date) - new Date(a.date));

  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 1220, margin: "0 auto" }}>
      <Breadcrumb trail={["Produk"]} setPage={setPage} />
      <div className="reveal" style={{ marginBottom: 30 }}><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>KATALOG</span><h1 style={{ fontSize: "clamp(1.9rem,3.6vw,2.6rem)", margin: "10px 0" }}>Produk Vantara</h1></div>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 20, alignItems: "center" }}>
        <div style={{ position: "relative", flex: "1 1 220px" }}><Search size={15} style={{ position: "absolute", left: 13, top: 13, color: "var(--text-dim)" }} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari produk..." style={{ paddingLeft: 36 }} /></div>
        <select value={sort} onChange={(e) => setSort(e.target.value)} style={{ width: 190 }}>
          <option value="newest">Terbaru</option><option value="price-asc">Harga Terendah</option><option value="price-desc">Harga Tertinggi</option><option value="name">Nama A-Z</option>
        </select>
      </div>
      <div style={{ display: "flex", gap: 9, flexWrap: "wrap", marginBottom: 32 }}>{CATS.map((c) => <button key={c} className={`chip ${cat === c ? "active" : ""}`} onClick={() => setCat(c)}>{c}</button>)}</div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }} className="grid-responsive-3">
        {filtered.map((p) => (
          <div key={p.id} className="glass card-hover reveal" style={{ overflow: "hidden" }}>
            <div onClick={() => setDetail(p)} style={{ height: 150, cursor: "pointer", fontSize: "3.4rem", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(150deg,var(--surface2),var(--surface))", position: "relative" }}>
              {p.emoji}
              <ZoomIn size={16} style={{ position: "absolute", bottom: 10, right: 10, color: "var(--text-dim)" }} />
              <Heart size={17} onClick={(e) => { e.stopPropagation(); toggleWish(p.id); }} fill={wishlist[p.id] ? "#E15C5C" : "none"} color={wishlist[p.id] ? "#E15C5C" : "var(--text-dim)"} style={{ position: "absolute", top: 10, right: 10, cursor: "pointer" }} />
            </div>
            <div style={{ padding: 18 }}>
              <span className="chip" style={{ fontSize: "0.66rem", padding: "3px 9px" }}>{p.cat}</span>
              <h3 onClick={() => setDetail(p)} style={{ fontSize: "0.98rem", textTransform: "none", margin: "10px 0 6px", cursor: "pointer" }}>{p.name}</h3>
              <div className="grad-text font-display" style={{ fontSize: "1.15rem", marginBottom: 12 }}>Rp {p.price.toLocaleString("id-ID")}</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button className="btn-primary btn" style={{ fontSize: "0.76rem", padding: "8px 14px" }} onClick={() => addToCart(p)}>+ Keranjang</button>
                <button className="btn-outline btn" style={{ fontSize: "0.76rem", padding: "8px 14px" }} onClick={() => { setPage("contact"); toast(`Permintaan penawaran untuk ${p.name} — lengkapi form kontak.`); }}>Minta Penawaran</button>
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <p style={{ color: "var(--text-dim)", gridColumn: "1/-1", textAlign: "center" }}>Tidak ada produk yang cocok.</p>}
      </div>
      {detail && <ProductDetail product={detail} onClose={() => setDetail(null)} addToCart={addToCart} wishlist={wishlist} toggleWish={toggleWish} />}
      <style>{`@media(max-width:860px){.grid-responsive-3{grid-template-columns:1fr !important;}}`}</style>
    </section>
  );
}

/* =========================================================
   SERVICES
========================================================= */
function Services({ setPage }) {
  useReveal(); const toast = useToast();
  const [form, setForm] = useState({ nama: "", email: "", layanan: SERVICES[0].name, pesan: "" });
  const [showForm, setShowForm] = useState(null);
  async function submit(e) {
    e.preventDefault();
    if (!form.nama.trim() || !/^\S+@\S+\.\S+$/.test(form.email)) return toast("Lengkapi nama dan email dengan benar.", "error");
    try { await storage.set(`service_request:${Date.now()}`, JSON.stringify(form), false); toast("Permintaan layanan terkirim! Tim kami akan menghubungi Anda."); setShowForm(null); setForm({ nama: "", email: "", layanan: SERVICES[0].name, pesan: "" }); }
    catch (e) { toast("Gagal mengirim permintaan.", "error"); }
  }
  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 1150, margin: "0 auto" }}>
      <Breadcrumb trail={["Layanan"]} setPage={setPage} />
      <div className="reveal" style={{ textAlign: "center", maxWidth: 620, margin: "0 auto 50px" }}><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>LAYANAN</span><h1 style={{ fontSize: "clamp(1.9rem,3.6vw,2.6rem)", margin: "10px 0" }}>Layanan Profesional Kami</h1></div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 20 }} className="grid-responsive-2">
        {SERVICES.map((s) => (
          <div key={s.id} className="glass card-hover reveal" style={{ padding: 26 }}>
            <div className="icon-wrap"><s.icon size={20} /></div>
            <h3 style={{ fontSize: "1.05rem", textTransform: "none", margin: "14px 0 8px" }}>{s.name}</h3>
            <p style={{ color: "var(--text-dim)", fontSize: "0.88rem", marginBottom: 16 }}>{s.desc}</p>
            <button className="btn-primary btn" style={{ fontSize: "0.82rem" }} onClick={() => { setForm({ ...form, layanan: s.name }); setShowForm(s); }}>Konsultasi Sekarang</button>
          </div>
        ))}
      </div>
      {showForm && (
        <Modal onClose={() => setShowForm(null)}>
          <h3 style={{ marginBottom: 4 }}>Formulir Permintaan Layanan</h3>
          <p style={{ color: "var(--text-dim)", fontSize: "0.85rem", marginBottom: 18 }}>{showForm.name}</p>
          <form onSubmit={submit}>
            <div style={{ marginBottom: 14 }}><label>Nama</label><input value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} required /></div>
            <div style={{ marginBottom: 14 }}><label>Email</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></div>
            <div style={{ marginBottom: 18 }}><label>Detail Kebutuhan</label><textarea value={form.pesan} onChange={(e) => setForm({ ...form, pesan: e.target.value })} /></div>
            <button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }}>Kirim Permintaan</button>
          </form>
        </Modal>
      )}
      <style>{`@media(max-width:860px){.grid-responsive-2{grid-template-columns:1fr !important;}}`}</style>
    </section>
  );
}

/* =========================================================
   TESTIMONIALS
========================================================= */
function Testimonials({ setPage }) {
  useReveal(); const toast = useToast();
  const [list, setList] = useState(TESTIMONIALS_SEED);
  const [idx, setIdx] = useState(0);
  const [form, setForm] = useState({ name: "", role: "", text: "", rating: 5 });
  useEffect(() => {
    (async () => { try { const r = await storage.get("testimonials_extra", true); if (r?.value) setList([...TESTIMONIALS_SEED, ...JSON.parse(r.value)]); } catch (e) {} })();
  }, []);
  useEffect(() => { const t = setInterval(() => setIdx((i) => (i + 1) % list.length), 4500); return () => clearInterval(t); }, [list.length]);
  async function submit(e) {
    e.preventDefault();
    if (!form.name.trim() || !form.text.trim()) return toast("Lengkapi nama dan ulasan Anda.", "error");
    try {
      const r = await storage.get("testimonials_extra", true).catch(() => null);
      const cur = r?.value ? JSON.parse(r.value) : [];
      const next = [...cur, { id: "u" + Date.now(), avatar: form.name.charAt(0).toUpperCase(), ...form }];
      await storage.set("testimonials_extra", JSON.stringify(next), true);
      setList([...TESTIMONIALS_SEED, ...next]);
      toast("Terima kasih! Ulasan Anda telah ditambahkan.");
      setForm({ name: "", role: "", text: "", rating: 5 });
    } catch (e) { toast("Gagal mengirim ulasan.", "error"); }
  }
  const cur = list[idx] || list[0];
  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 900, margin: "0 auto" }}>
      <Breadcrumb trail={["Testimoni"]} setPage={setPage} />
      <div className="reveal" style={{ textAlign: "center", marginBottom: 40 }}><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>TESTIMONI</span><h1 style={{ fontSize: "clamp(1.9rem,3.6vw,2.6rem)", margin: "10px 0" }}>Apa Kata Klien Kami</h1></div>

      {cur && (
        <div className="glass reveal" style={{ padding: 36, textAlign: "center", marginBottom: 40 }}>
          <div style={{ display: "flex", justifyContent: "center", gap: 3, marginBottom: 16, color: "#F2A93B" }}>{Array.from({ length: 5 }).map((_, i) => <Star key={i} size={17} fill={i < cur.rating ? "#F2A93B" : "none"} color={i < cur.rating ? "#F2A93B" : "var(--text-dim)"} />)}</div>
          <p style={{ fontSize: "1.1rem", fontStyle: "italic", marginBottom: 20 }}>"{cur.text}"</p>
          <div style={{ width: 54, height: 54, borderRadius: "50%", margin: "0 auto 10px", background: "linear-gradient(135deg,var(--gold),var(--steel))", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Playfair Display", color: "#181205" }}>{cur.avatar}</div>
          <div style={{ fontWeight: 700 }}>{cur.name}</div><div style={{ color: "var(--text-dim)", fontSize: "0.82rem" }}>{cur.role || ""}</div>
          <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 20 }}>{list.map((_, i) => <button key={i} onClick={() => setIdx(i)} style={{ width: 8, height: 8, borderRadius: "50%", border: "none", background: i === idx ? "var(--gold)" : "var(--border)", cursor: "pointer" }} />)}</div>
        </div>
      )}

      <div className="glass reveal" style={{ padding: 26 }}>
        <h3 style={{ fontSize: "1.02rem", marginBottom: 16 }}>Bagikan Pengalaman Anda</h3>
        <form onSubmit={submit}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }} className="grid-responsive-2">
            <div><label>Nama</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div><label>Peran / Perusahaan</label><input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} /></div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label>Rating</label>
            <div style={{ display: "flex", gap: 4 }}>{[1, 2, 3, 4, 5].map((n) => <Star key={n} size={22} onClick={() => setForm({ ...form, rating: n })} fill={form.rating >= n ? "#F2A93B" : "none"} color={form.rating >= n ? "#F2A93B" : "var(--text-dim)"} style={{ cursor: "pointer" }} />)}</div>
          </div>
          <div style={{ marginBottom: 16 }}><label>Ulasan</label><textarea value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} required /></div>
          <button className="btn-primary btn">Kirim Ulasan</button>
        </form>
      </div>
      <style>{`@media(max-width:640px){.grid-responsive-2{grid-template-columns:1fr !important;}}`}</style>
    </section>
  );
}

/* =========================================================
   ABOUT
========================================================= */
function About({ setPage }) {
  useReveal();
  const timeline = [["2018", "Vantara didirikan sebagai toko produk lifestyle skala kecil."], ["2020", "Ekspansi ke layanan konsultasi bisnis untuk UMKM."], ["2023", "Membuka gudang distribusi di 4 kota besar."], ["2026", "Melayani lebih dari 500 klien bisnis di seluruh Indonesia."]];
  const team = [["Andini Prameswari", "Chief Executive Officer", "👩‍💼"], ["Reza Firmansyah", "Head of Operations", "🧑‍💼"], ["Salsabila Putri", "Head of Consulting", "👩‍🏫"], ["Yusuf Maulana", "Head of Product", "🧑‍🔧"]];
  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 1100, margin: "0 auto" }}>
      <Breadcrumb trail={["Tentang Kami"]} setPage={setPage} />
      <div className="reveal" style={{ textAlign: "center", maxWidth: 680, margin: "0 auto 50px" }}>
        <span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>TENTANG KAMI</span>
        <h1 style={{ fontSize: "clamp(1.9rem,3.6vw,2.6rem)", margin: "12px 0" }}>Membangun Kepercayaan Lewat Kualitas</h1>
        <p style={{ color: "var(--text-dim)" }}>Vantara berkomitmen menghadirkan produk premium dan layanan konsultasi yang membantu individu dan bisnis berkembang dengan percaya diri.</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 60 }} className="grid-responsive-2">
        <div className="glass reveal" style={{ padding: 26 }}><h3 style={{ fontSize: "1rem", marginBottom: 8 }}>Visi</h3><p style={{ color: "var(--text-dim)", fontSize: "0.9rem" }}>Menjadi mitra tepercaya nomor satu untuk solusi produk dan konsultasi bisnis di Indonesia.</p></div>
        <div className="glass reveal" style={{ padding: 26 }}><h3 style={{ fontSize: "1rem", marginBottom: 8 }}>Misi</h3><p style={{ color: "var(--text-dim)", fontSize: "0.9rem" }}>Menghadirkan produk berkualitas tinggi dan layanan yang personal, transparan, dan berdampak nyata.</p></div>
      </div>

      <div className="reveal" style={{ marginBottom: 24 }}><h2 style={{ fontSize: "1.5rem", textAlign: "center", marginBottom: 30 }}>Perjalanan Kami</h2>
        {timeline.map(([y, d], i) => (
          <div key={y} style={{ display: "flex", gap: 20, marginBottom: 22 }}>
            <div className="font-display grad-text" style={{ fontSize: "1.3rem", width: 70, flexShrink: 0 }}>{y}</div>
            <div style={{ borderLeft: "2px solid var(--border)", paddingLeft: 20, color: "var(--text-dim)", fontSize: "0.9rem" }}>{d}</div>
          </div>
        ))}
      </div>

      <h2 style={{ fontSize: "1.5rem", textAlign: "center", margin: "50px 0 24px" }}>Tim Kami</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }} className="grid-responsive-4">
        {team.map(([n, r, e]) => <div key={n} className="glass card-hover reveal" style={{ padding: 20, textAlign: "center" }}><div style={{ fontSize: "2.2rem", marginBottom: 8 }}>{e}</div><div style={{ fontWeight: 700, fontSize: "0.88rem" }}>{n}</div><div style={{ color: "var(--text-dim)", fontSize: "0.76rem" }}>{r}</div></div>)}
      </div>
      <style>{`@media(max-width:900px){.grid-responsive-2{grid-template-columns:1fr !important;} .grid-responsive-4{grid-template-columns:repeat(2,1fr) !important;}}`}</style>
    </section>
  );
}

/* =========================================================
   BLOG
========================================================= */
function BlogDetail({ article, onClose, toast }) {
  const related = ARTICLES.filter((a) => a.category === article.category && a.id !== article.id).slice(0, 2);
  return (
    <Modal onClose={onClose}>
      <span className="chip active" style={{ padding: "4px 12px", fontSize: "0.7rem" }}>{article.category}</span>
      <h2 style={{ margin: "14px 0 8px", textTransform: "none", fontSize: "1.35rem" }}>{article.title}</h2>
      <div style={{ display: "flex", gap: 14, color: "var(--text-dim)", fontSize: "0.78rem", marginBottom: 16 }}><span><Clock size={12} style={{ verticalAlign: -2 }} /> {article.read} menit baca</span><span>{article.date}</span></div>
      <p style={{ color: "var(--text-dim)", lineHeight: 1.8, fontSize: "0.92rem", marginBottom: 18 }}>{article.excerpt} Kami menyusun artikel ini agar pembaca dapat langsung menerapkan wawasannya, baik untuk kebutuhan pribadi maupun operasional bisnis sehari-hari.</p>
      <button className="btn-outline btn" style={{ marginBottom: 20 }} onClick={() => navigator.share ? navigator.share({ title: article.title }) : (navigator.clipboard.writeText(article.title), toast("Judul disalin ke clipboard."))}><Share2 size={14} /> Bagikan</button>
      {related.length > 0 && <div><div className="mono" style={{ fontSize: "0.7rem", color: "var(--text-dim)", marginBottom: 8 }}>ARTIKEL TERKAIT</div>{related.map((r) => <div key={r.id} style={{ fontSize: "0.86rem", padding: "8px 0", borderBottom: "1px solid var(--border)" }}>{r.emoji} {r.title}</div>)}</div>}
    </Modal>
  );
}
function Blog({ setPage }) {
  useReveal(); const toast = useToast();
  const [cat, setCat] = useState("Semua"); const [q, setQ] = useState(""); const [open, setOpen] = useState(null);
  const filtered = ARTICLES.filter((a) => (cat === "Semua" || a.category === cat) && a.title.toLowerCase().includes(q.toLowerCase()));
  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 1150, margin: "0 auto" }}>
      <Breadcrumb trail={["Blog"]} setPage={setPage} />
      <div className="reveal" style={{ textAlign: "center", maxWidth: 620, margin: "0 auto 36px" }}><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>BLOG</span><h1 style={{ fontSize: "clamp(1.9rem,3.6vw,2.6rem)", margin: "10px 0" }}>Wawasan & Tips</h1></div>
      <div style={{ display: "flex", justifyContent: "center", marginBottom: 20 }}><div style={{ position: "relative", width: "100%", maxWidth: 400 }}><Search size={15} style={{ position: "absolute", left: 13, top: 13, color: "var(--text-dim)" }} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari artikel..." style={{ paddingLeft: 36 }} /></div></div>
      <div style={{ display: "flex", gap: 9, justifyContent: "center", marginBottom: 36, flexWrap: "wrap" }}>{ART_CATS.map((c) => <button key={c} className={`chip ${cat === c ? "active" : ""}`} onClick={() => setCat(c)}>{c}</button>)}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 20 }} className="grid-responsive-2">
        {filtered.map((a) => (
          <div key={a.id} className="glass card-hover reveal" style={{ overflow: "hidden", display: "flex" }}>
            <div onClick={() => setOpen(a)} style={{ width: 120, flexShrink: 0, cursor: "pointer", fontSize: "2.6rem", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(150deg,var(--surface2),var(--surface))" }}>{a.emoji}</div>
            <div style={{ padding: 18 }}>
              <span className="chip" style={{ fontSize: "0.64rem", padding: "3px 9px" }}>{a.category}</span>
              <h3 onClick={() => setOpen(a)} style={{ fontSize: "0.96rem", textTransform: "none", margin: "9px 0 6px", cursor: "pointer" }}>{a.title}</h3>
              <p style={{ color: "var(--text-dim)", fontSize: "0.82rem", marginBottom: 10 }}>{a.excerpt}</p>
              <span style={{ fontSize: "0.74rem", color: "var(--text-dim)" }}><Clock size={11} style={{ verticalAlign: -2 }} /> {a.read} menit · {a.date}</span>
            </div>
          </div>
        ))}
      </div>
      {open && <BlogDetail article={open} onClose={() => setOpen(null)} toast={toast} />}
      <style>{`@media(max-width:760px){.grid-responsive-2{grid-template-columns:1fr !important;}}`}</style>
    </section>
  );
}

/* =========================================================
   FAQ
========================================================= */
function FAQ({ setPage }) {
  useReveal();
  const [openIdx, setOpenIdx] = useState(null); const [q, setQ] = useState("");
  const filtered = FAQS.filter((f) => f.q.toLowerCase().includes(q.toLowerCase()));
  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 760, margin: "0 auto" }}>
      <Breadcrumb trail={["FAQ"]} setPage={setPage} />
      <div className="reveal" style={{ textAlign: "center", marginBottom: 30 }}><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>FAQ</span><h1 style={{ fontSize: "clamp(1.9rem,3.6vw,2.4rem)", margin: "10px 0" }}>Pertanyaan Umum</h1></div>
      <div style={{ position: "relative", marginBottom: 30 }}><Search size={15} style={{ position: "absolute", left: 13, top: 13, color: "var(--text-dim)" }} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari pertanyaan..." style={{ paddingLeft: 36 }} /></div>
      {filtered.map((f, i) => (
        <div key={i} className={`glass reveal faq-item ${openIdx === i ? "open" : ""}`} style={{ marginBottom: 10, padding: "4px 20px" }}>
          <button onClick={() => setOpenIdx(openIdx === i ? null : i)} style={{ width: "100%", background: "none", border: "none", color: "var(--text)", padding: "16px 0", display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer", fontSize: "0.95rem", fontWeight: 600, textAlign: "left" }}>{f.q} <ChevronDown className="accordion-icon" size={17} color="var(--gold)" /></button>
          {openIdx === i && <p style={{ color: "var(--text-dim)", paddingBottom: 16, fontSize: "0.88rem" }}>{f.a}</p>}
        </div>
      ))}
      {filtered.length === 0 && <p style={{ color: "var(--text-dim)", textAlign: "center" }}>Tidak ditemukan pertanyaan yang cocok.</p>}
    </section>
  );
}

/* =========================================================
   CONTACT
========================================================= */
function Contact({ setPage }) {
  useReveal(); const toast = useToast();
  const [form, setForm] = useState({ nama: "", email: "", wa: "", subjek: "", pesan: "" });
  const [errors, setErrors] = useState({}); const [sending, setSending] = useState(false); const [newsletterEmail, setNewsletterEmail] = useState("");
  function validate() {
    const e = {};
    if (!form.nama.trim()) e.nama = "Nama wajib diisi.";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = "Format email tidak valid.";
    if (!/^[0-9+ ]{8,15}$/.test(form.wa)) e.wa = "Nomor WhatsApp tidak valid.";
    if (!form.subjek.trim()) e.subjek = "Subjek wajib diisi.";
    if (!form.pesan.trim() || form.pesan.length < 10) e.pesan = "Pesan minimal 10 karakter.";
    setErrors(e); return Object.keys(e).length === 0;
  }
  async function submit(ev) {
    ev.preventDefault();
    if (!validate()) return toast("Periksa kembali data formulir Anda.", "error");
    setSending(true);
    try { await storage.set(`contact:${Date.now()}`, JSON.stringify(form), false); toast("Pesan berhasil dikirim! Tim kami akan segera menghubungi Anda."); setForm({ nama: "", email: "", wa: "", subjek: "", pesan: "" }); }
    catch (e) { toast("Gagal mengirim pesan. Coba lagi.", "error"); } finally { setSending(false); }
  }
  async function submitNewsletter(ev) {
    ev.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(newsletterEmail)) return toast("Masukkan email yang valid.", "error");
    try { await storage.set(`newsletter:${Date.now()}`, newsletterEmail, false); toast("Berhasil berlangganan newsletter!"); setNewsletterEmail(""); }
    catch (e) { toast("Gagal berlangganan.", "error"); }
  }
  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 1100, margin: "0 auto" }}>
      <Breadcrumb trail={["Kontak"]} setPage={setPage} />
      <div className="reveal" style={{ textAlign: "center", maxWidth: 600, margin: "0 auto 40px" }}><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>KONTAK</span><h1 style={{ fontSize: "clamp(1.9rem,3.6vw,2.6rem)", margin: "10px 0" }}>Mari Terhubung</h1></div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 34 }} className="grid-responsive-2">
        <form className="reveal glass" style={{ padding: 26 }} onSubmit={submit} noValidate>
          <div style={{ marginBottom: 14 }}><label>Nama</label><input value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} />{errors.nama && <span style={{ color: "#E15C5C", fontSize: "0.74rem" }}>{errors.nama}</span>}</div>
          <div style={{ marginBottom: 14 }}><label>Email</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />{errors.email && <span style={{ color: "#E15C5C", fontSize: "0.74rem" }}>{errors.email}</span>}</div>
          <div style={{ marginBottom: 14 }}><label>Nomor WhatsApp</label><input value={form.wa} onChange={(e) => setForm({ ...form, wa: e.target.value })} placeholder="08xx-xxxx-xxxx" />{errors.wa && <span style={{ color: "#E15C5C", fontSize: "0.74rem" }}>{errors.wa}</span>}</div>
          <div style={{ marginBottom: 14 }}><label>Subjek</label><input value={form.subjek} onChange={(e) => setForm({ ...form, subjek: e.target.value })} />{errors.subjek && <span style={{ color: "#E15C5C", fontSize: "0.74rem" }}>{errors.subjek}</span>}</div>
          <div style={{ marginBottom: 18 }}><label>Pesan</label><textarea value={form.pesan} onChange={(e) => setForm({ ...form, pesan: e.target.value })} />{errors.pesan && <span style={{ color: "#E15C5C", fontSize: "0.74rem" }}>{errors.pesan}</span>}</div>
          <button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }} disabled={sending}>{sending ? <><Loader2 size={16} className="spin" /> Mengirim...</> : "Kirim Pesan"}</button>
        </form>
        <div className="reveal">
          <div className="glass" style={{ padding: 24, marginBottom: 16 }}>
            <div style={{ display: "flex", gap: 12, marginBottom: 13, fontSize: "0.87rem", color: "var(--text-dim)" }}><MapPin size={16} color="var(--gold)" /> Jl. Wakaakaa</div>
            <div style={{ display: "flex", gap: 12, marginBottom: 13, fontSize: "0.87rem", color: "var(--text-dim)" }}><Phone size={16} color="var(--gold)" /> +62 813-5174-0944</div>
            <div style={{ display: "flex", gap: 12, marginBottom: 13, fontSize: "0.87rem", color: "var(--text-dim)" }}><Mail size={16} color="var(--gold)" /> Fyn_bagaskara@gmail.com</div>
            <a href="https://wa.me/6281351740944?text=Halo%20Vantara%2C%20saya%20ingin%20bertanya" className="btn-primary btn" style={{ width: "100%", justifyContent: "center", marginTop: 6 }}>Chat via WhatsApp</a>
          </div>
          <div className="glass" style={{ overflow: "hidden", height: 190, marginBottom: 16 }}><iframe title="Lokasi Vantara" src="https://www.google.com/maps?q=Jl.+Wakaakaa&output=embed" style={{ width: "100%", height: "100%", border: 0 }} loading="lazy" referrerPolicy="no-referrer-when-downgrade" /></div>
          <form className="glass" style={{ padding: 20 }} onSubmit={submitNewsletter}>
            <label>Berlangganan Newsletter</label>
            <div style={{ display: "flex", gap: 8 }}><input type="email" value={newsletterEmail} onChange={(e) => setNewsletterEmail(e.target.value)} placeholder="email@anda.com" /><button className="btn-outline btn" style={{ padding: "11px 15px" }}>Kirim</button></div>
          </form>
        </div>
      </div>
      <style>{`@media(max-width:860px){.grid-responsive-2{grid-template-columns:1fr !important;}}`}</style>
    </section>
  );
}

/* =========================================================
   AUTH (login/register + admin gate)
========================================================= */
function AuthPage({ session, setSession, setPage }) {
  useReveal(); const toast = useToast();
  const [tab, setTab] = useState("login"); const [showPw, setShowPw] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "" }); const [loading, setLoading] = useState(false);

  async function register(e) {
    e.preventDefault();
    if (!form.name.trim() || !/^\S+@\S+\.\S+$/.test(form.email) || form.password.length < 6) return toast("Lengkapi data dengan benar (password minimal 6 karakter).", "error");
    setLoading(true);
    try {
      const existing = await storage.get(`user:${form.email}`, true).catch(() => null);
      if (existing?.value) { toast("Email sudah terdaftar. Silakan masuk.", "error"); setTab("login"); setLoading(false); return; }
      await storage.set(`user:${form.email}`, JSON.stringify({ name: form.name, email: form.email }), true);
      await storage.set("session", JSON.stringify({ name: form.name, email: form.email }), false);
      setSession({ name: form.name, email: form.email }); toast("Registrasi berhasil!"); setPage("home");
    } catch (e) { toast("Gagal mendaftar.", "error"); } finally { setLoading(false); }
  }
  async function login(e) {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return toast("Masukkan email yang valid.", "error");
    setLoading(true);
    try {
      const r = await storage.get(`user:${form.email}`, true).catch(() => null);
      if (!r?.value) { toast("Akun tidak ditemukan. Silakan daftar.", "error"); setTab("register"); setLoading(false); return; }
      const user = JSON.parse(r.value);
      await storage.set("session", JSON.stringify(user), false);
      setSession(user); toast(`Selamat datang kembali, ${user.name}!`); setPage("home");
    } catch (e) { toast("Gagal masuk.", "error"); } finally { setLoading(false); }
  }
  async function forgot(e) { e.preventDefault(); toast("Tautan reset password (demo) telah 'dikirim' ke email Anda."); setTab("login"); }
  async function logout() { try { await storage.delete("session", false); } catch (e) {} setSession(null); toast("Anda telah keluar."); }

  if (session) {
    return (
      <section style={{ padding: "150px 24px 90px", maxWidth: 460, margin: "0 auto" }}>
        <div className="glass reveal" style={{ padding: 32, textAlign: "center" }}>
          <div style={{ width: 70, height: 70, borderRadius: "50%", margin: "0 auto 14px", background: "linear-gradient(135deg,var(--gold),var(--steel))", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Playfair Display", fontSize: "1.5rem", color: "#181205" }}>{session.name.charAt(0).toUpperCase()}</div>
          <h2 style={{ textTransform: "none" }}>{session.name}</h2>
          <p style={{ color: "var(--text-dim)", fontSize: "0.86rem", marginBottom: 22 }}>{session.email}</p>
          <div style={{ display: "flex", gap: 10, justifyContent: "center" }}><button className="btn-outline btn" onClick={logout}><LogOut size={14} /> Keluar</button></div>
        </div>
      </section>
    );
  }
  return (
    <section style={{ padding: "150px 24px 90px", maxWidth: 440, margin: "0 auto" }}>
      <div className="glass reveal" style={{ padding: 30 }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>{["login", "register", "forgot"].map((t) => <button key={t} className={`chip ${tab === t ? "active" : ""}`} style={{ flex: 1, textAlign: "center" }} onClick={() => setTab(t)}>{t === "login" ? "Masuk" : t === "register" ? "Daftar" : "Lupa Sandi"}</button>)}</div>
        {tab === "register" && (
          <form onSubmit={register}>
            <div style={{ marginBottom: 14 }}><label>Nama Lengkap</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div style={{ marginBottom: 14 }}><label>Email</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></div>
            <div style={{ marginBottom: 20 }}><label>Kata Sandi</label><div style={{ position: "relative" }}><input type={showPw ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required /><button type="button" onClick={() => setShowPw(!showPw)} style={{ position: "absolute", right: 12, top: 11, background: "none", border: "none", color: "var(--text-dim)", cursor: "pointer" }}>{showPw ? <EyeOff size={15} /> : <Eye size={15} />}</button></div></div>
            <button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }} disabled={loading}>{loading ? <Loader2 size={16} className="spin" /> : "Daftar Sekarang"}</button>
          </form>
        )}
        {tab === "login" && (
          <form onSubmit={login}>
            <div style={{ marginBottom: 14 }}><label>Email</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></div>
            <div style={{ marginBottom: 20 }}><label>Kata Sandi</label><div style={{ position: "relative" }}><input type={showPw ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required /><button type="button" onClick={() => setShowPw(!showPw)} style={{ position: "absolute", right: 12, top: 11, background: "none", border: "none", color: "var(--text-dim)", cursor: "pointer" }}>{showPw ? <EyeOff size={15} /> : <Eye size={15} />}</button></div></div>
            <button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }} disabled={loading}>{loading ? <Loader2 size={16} className="spin" /> : "Masuk"}</button>
          </form>
        )}
        {tab === "forgot" && (<form onSubmit={forgot}><div style={{ marginBottom: 20 }}><label>Email Terdaftar</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></div><button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }}>Kirim Tautan Reset</button></form>)}
        <p style={{ marginTop: 16, fontSize: "0.7rem", color: "var(--text-dim)", textAlign: "center" }}>Demo autentikasi — bukan sistem produksi.</p>
      </div>
    </section>
  );
}

/* =========================================================
   ADMIN DASHBOARD
========================================================= */
const VISIT_DATA = [{ d: "Sen", v: 240 }, { d: "Sel", v: 310 }, { d: "Rab", v: 280 }, { d: "Kam", v: 390 }, { d: "Jum", v: 340 }, { d: "Sab", v: 210 }, { d: "Min", v: 180 }];

function AdminDashboard() {
  useReveal(); const toast = useToast();
  const [authed, setAuthed] = useState(false);
  const [cred, setCred] = useState({ email: "", password: "" });
  const [tab, setTab] = useState("produk");
  const [products, setProducts] = useState(PRODUCTS_SEED);
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const [newProduct, setNewProduct] = useState({ name: "", cat: "Elektronik", price: "", desc: "" });

  useEffect(() => { if (authed) loadAll(); }, [authed]);
  async function loadAll() {
    try {
      const extra = await storage.get("admin_products_extra", true).catch(() => null);
      setProducts([...PRODUCTS_SEED, ...(extra?.value ? JSON.parse(extra.value) : [])]);
    } catch (e) {}
    try {
      const list = await storage.list("contact:", false);
      const items = [];
      for (const k of (list?.keys || []).slice(-15)) { const r = await storage.get(k, false).catch(() => null); if (r?.value) items.push(JSON.parse(r.value)); }
      setMessages(items.reverse());
    } catch (e) {}
    try {
      const list = await storage.list("user:", true);
      const items = [];
      for (const k of (list?.keys || [])) { const r = await storage.get(k, true).catch(() => null); if (r?.value) items.push(JSON.parse(r.value)); }
      setUsers(items);
    } catch (e) {}
  }
  function adminLogin(e) {
    e.preventDefault();
    if (cred.email === "admin@vantara.id" && cred.password === "admin123") { setAuthed(true); toast("Berhasil masuk sebagai Admin."); }
    else toast("Kredensial admin salah. (Demo: admin@vantara.id / admin123)", "error");
  }
  async function addProduct(e) {
    e.preventDefault();
    if (!newProduct.name.trim() || !newProduct.price) return toast("Lengkapi nama dan harga produk.", "error");
    try {
      const extra = await storage.get("admin_products_extra", true).catch(() => null);
      const cur = extra?.value ? JSON.parse(extra.value) : [];
      const next = [...cur, { id: "u" + Date.now(), emoji: "📦", date: new Date().toISOString().slice(0, 10), ...newProduct, price: Number(newProduct.price) }];
      await storage.set("admin_products_extra", JSON.stringify(next), true);
      setProducts([...PRODUCTS_SEED, ...next]); toast("Produk ditambahkan."); setNewProduct({ name: "", cat: "Elektronik", price: "", desc: "" });
    } catch (e) { toast("Gagal menambah produk.", "error"); }
  }
  async function deleteProduct(id) {
    if (PRODUCTS_SEED.find((p) => p.id === id)) return toast("Produk contoh bawaan tidak bisa dihapus di demo ini.", "error");
    try {
      const extra = await storage.get("admin_products_extra", true).catch(() => null);
      const cur = extra?.value ? JSON.parse(extra.value) : [];
      const next = cur.filter((p) => p.id !== id);
      await storage.set("admin_products_extra", JSON.stringify(next), true);
      setProducts([...PRODUCTS_SEED, ...next]); toast("Produk dihapus.");
    } catch (e) { toast("Gagal menghapus produk.", "error"); }
  }

  if (!authed) {
    return (
      <section style={{ padding: "150px 24px 90px", maxWidth: 420, margin: "0 auto" }}>
        <div className="glass reveal" style={{ padding: 30 }}>
          <div className="icon-wrap" style={{ margin: "0 auto 14px" }}><LayoutDashboard size={20} /></div>
          <h2 style={{ textAlign: "center", marginBottom: 6 }}>Login Admin</h2>
          <p style={{ textAlign: "center", color: "var(--text-dim)", fontSize: "0.8rem", marginBottom: 20 }}>Demo: admin@vantara.id / admin123</p>
          <form onSubmit={adminLogin}>
            <div style={{ marginBottom: 14 }}><label>Email Admin</label><input value={cred.email} onChange={(e) => setCred({ ...cred, email: e.target.value })} required /></div>
            <div style={{ marginBottom: 20 }}><label>Kata Sandi</label><input type="password" value={cred.password} onChange={(e) => setCred({ ...cred, password: e.target.value })} required /></div>
            <button className="btn-primary btn" style={{ width: "100%", justifyContent: "center" }}>Masuk sebagai Admin</button>
          </form>
        </div>
      </section>
    );
  }

  const tabs = [["produk", "Produk"], ["pesan", "Pesan Kontak"], ["pengguna", "Pengguna"], ["statistik", "Statistik"]];
  return (
    <section style={{ padding: "120px 24px 90px", maxWidth: 1150, margin: "0 auto" }}>
      <div className="reveal" style={{ marginBottom: 30, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div><span className="mono" style={{ color: "var(--gold)", fontSize: "0.76rem" }}>ADMIN</span><h1 style={{ fontSize: "clamp(1.7rem,3.2vw,2.2rem)", margin: "6px 0" }}>Dashboard Admin</h1></div>
        <button className="btn-outline btn" onClick={() => setAuthed(false)}><LogOut size={14} /> Keluar Admin</button>
      </div>
      <div style={{ display: "flex", gap: 9, marginBottom: 28, flexWrap: "wrap" }}>{tabs.map(([k, l]) => <button key={k} className={`chip ${tab === k ? "active" : ""}`} onClick={() => setTab(k)}>{l}</button>)}</div>

      {tab === "produk" && (
        <div className="reveal">
          <div className="glass" style={{ padding: 22, marginBottom: 20 }}>
            <h3 style={{ fontSize: "0.95rem", marginBottom: 14 }}>Tambah Produk Baru</h3>
            <form onSubmit={addProduct} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr auto", gap: 10 }} className="grid-admin-form">
              <input placeholder="Nama produk" value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} />
              <select value={newProduct.cat} onChange={(e) => setNewProduct({ ...newProduct, cat: e.target.value })}>{CATS.filter((c) => c !== "Semua").map((c) => <option key={c}>{c}</option>)}</select>
              <input type="number" placeholder="Harga" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} />
              <button className="btn-primary btn"><Plus size={15} /></button>
            </form>
          </div>
          <div className="glass" style={{ overflow: "hidden" }}>
            {products.map((p) => (
              <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 20px", borderBottom: "1px solid var(--border)" }}>
                <span style={{ fontSize: "1.5rem" }}>{p.emoji}</span>
                <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: "0.88rem" }}>{p.name}</div><div style={{ color: "var(--text-dim)", fontSize: "0.76rem" }}>{p.cat} · Rp {p.price.toLocaleString("id-ID")}</div></div>
                <Trash2 size={16} onClick={() => deleteProduct(p.id)} style={{ cursor: "pointer", color: "var(--text-dim)" }} />
              </div>
            ))}
          </div>
        </div>
      )}
      {tab === "pesan" && (
        <div className="glass reveal" style={{ overflow: "hidden" }}>
          {messages.length === 0 && <p style={{ padding: 20, color: "var(--text-dim)", fontSize: "0.86rem" }}>Belum ada pesan masuk dari formulir kontak.</p>}
          {messages.map((m, i) => (
            <div key={i} style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem", fontWeight: 700 }}><span>{m.nama}</span><span style={{ color: "var(--text-dim)", fontWeight: 400 }}>{m.email}</span></div>
              <div style={{ color: "var(--gold)", fontSize: "0.78rem", margin: "4px 0" }}>{m.subjek}</div>
              <div style={{ color: "var(--text-dim)", fontSize: "0.83rem" }}>{m.pesan}</div>
            </div>
          ))}
        </div>
      )}
      {tab === "pengguna" && (
        <div className="glass reveal" style={{ overflow: "hidden" }}>
          {users.length === 0 && <p style={{ padding: 20, color: "var(--text-dim)", fontSize: "0.86rem" }}>Belum ada pengguna terdaftar.</p>}
          {users.map((u, i) => <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "13px 20px", borderBottom: "1px solid var(--border)", fontSize: "0.86rem" }}><span style={{ fontWeight: 700 }}>{u.name}</span><span style={{ color: "var(--text-dim)" }}>{u.email}</span></div>)}
        </div>
      )}
      {tab === "statistik" && (
        <div className="glass reveal" style={{ padding: 24 }}>
          <h3 style={{ fontSize: "0.95rem", marginBottom: 16 }}>Pengunjung 7 Hari Terakhir (ilustratif)</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={VISIT_DATA}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="d" stroke="#9BA3B4" fontSize={12} /><YAxis stroke="#9BA3B4" fontSize={12} /><Tooltip contentStyle={{ background: "var(--surface)", border: "1px solid var(--border)" }} /><Bar dataKey="v" fill="var(--gold)" radius={[6, 6, 0, 0]} /></BarChart>
          </ResponsiveContainer>
          <p style={{ color: "var(--text-dim)", fontSize: "0.78rem", marginTop: 10 }}>Data ilustratif — hubungkan Google Analytics API di backend untuk statistik pengunjung sungguhan.</p>
        </div>
      )}
      <style>{`@media(max-width:700px){.grid-admin-form{grid-template-columns:1fr !important;}}`}</style>
    </section>
  );
}

/* =========================================================
   APP ROOT
========================================================= */
function AppInner() {
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState("home");
  const [session, setSession] = useState(null);
  const [theme, setTheme] = useState("dark");
  const [lang, setLang] = useState("id");
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1700);
    (async () => {
      try { const r = await storage.get("session", false); if (r?.value) setSession(JSON.parse(r.value)); } catch (e) {}
      try { const c = await storage.get("cart", false); if (c?.value) setCart(JSON.parse(c.value)); } catch (e) {}
    })();
    return () => clearTimeout(t);
  }, []);

  const tFn = (k) => DICT[lang][k] || k;
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  const pages = {
    home: <Home setPage={setPage} setShowChat={setShowChat} />,
    products: <Products setPage={setPage} session={session} />,
    services: <Services setPage={setPage} />,
    testimonials: <Testimonials setPage={setPage} />,
    about: <About setPage={setPage} />,
    blog: <Blog setPage={setPage} />,
    faq: <FAQ setPage={setPage} />,
    contact: <Contact setPage={setPage} />,
    dashboard: <AdminDashboard />,
    auth: <AuthPage session={session} setSession={setSession} setPage={setPage} />,
  };

  return (
    <LangCtx.Provider value={{ lang, t: tFn }}>
      <div className="app" data-theme={theme}>
        <GlobalStyles />
        <LoadingScreen show={loading} />
        {!loading && (
          <>
            <ScrollProgress />
            <Navbar page={page} setPage={setPage} session={session} theme={theme} setTheme={setTheme} lang={lang} setLang={setLang} cartCount={cartCount} setShowCart={setShowCart} setShowChat={setShowChat} setShowSearch={setShowSearch} />
            {pages[page]}
            <Footer setPage={setPage} />
            <BackToTop />
            <PromoPopup />
            <ChatWidget open={showChat} setOpen={setShowChat} />
            <a href="https://wa.me/6281351740944?text=Halo%20Vantara%2C%20saya%20ingin%20bertanya" className="pulse" style={{ position: "fixed", bottom: 24, right: showChat ? -100 : 24, transition: "right .3s", width: 52, height: 52, borderRadius: "50%", background: "#25D366", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 230, boxShadow: "0 8px 24px rgba(0,0,0,0.35)" }} aria-label="WhatsApp"><Phone size={20} /></a>
            {!showChat && <button className="btn-primary pulse" onClick={() => setShowChat(true)} aria-label="Buka live chat" style={{ position: "fixed", bottom: 88, right: 24, width: 52, height: 52, borderRadius: "50%", padding: 0, justifyContent: "center", zIndex: 240 }}><Bot size={20} /></button>}
            <SearchOverlay show={showSearch} onClose={() => setShowSearch(false)} setPage={setPage} />
            <CartDrawer show={showCart} onClose={() => setShowCart(false)} cart={cart} setCart={setCart} setPage={setPage} />
          </>
        )}
      </div>
    </LangCtx.Provider>
  );
}

export default function App() {
  return (<ToastProvider><AppInner /></ToastProvider>);
}
